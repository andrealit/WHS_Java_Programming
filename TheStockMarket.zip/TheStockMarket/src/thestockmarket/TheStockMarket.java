/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.

Standard option:
Complete a JFrame application to implement a madlib (provided by Mr. Tensa in class). You should have a label and text box for each input, and output your story to a text area. You should have 3 buttons:
- Create the mad lib
- Clear the input and output (i.e.start over)
- An exit button
For a 4, detect and require the user to fill in every input before generating the madlib.
Be sure to fully document your code. 

Advanced option:
You will perform calculations with triangles. For input, read 3 pairs of x-y coordinates. Your job is to compute and display the following properties:
- the lengths of all sides (Pythagorean theorem)
- the angles of all corners (law of cosines)
- the area (heron's formula)
- the perimeter (easy :-)

 */
package thestockmarket;

/**
 *
 * @author andreatongsak
 */
public class TheStockMarket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
